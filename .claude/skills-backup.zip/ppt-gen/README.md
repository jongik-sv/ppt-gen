# PPT Generation Service (ppt-gen)

AI 기반 PowerPoint 자동 생성 스킬. 텍스트 콘텐츠를 입력받아 전문가 수준의 프레젠테이션을 생성합니다.

> 📚 **처음 사용하시나요?** → [학습 가이드 (GUIDE.md)](GUIDE.md)를 참고하세요!

---

## 목차

1. [기능 개요](#기능-개요)
2. [PPT 생성 파이프라인 (5단계)](#ppt-생성-파이프라인-5단계)
3. [빠른 시작](#빠른-시작)
4. [워크플로우](#워크플로우)
5. [사용 예시](#사용-예시)
6. [템플릿 시스템](#템플릿-시스템)
7. [스크립트 사용법](#스크립트-사용법)
8. [폴더 구조](#폴더-구조)
9. [레퍼런스 문서](#레퍼런스-문서)
10. [트러블슈팅](#트러블슈팅)

---

## 기능 개요

### 핵심 기능

| 기능 | 설명 |
|------|------|
| **새 PPT 생성** | Markdown/텍스트 → 전문 디자인 PPT |
| **템플릿 기반 생성** | 브랜드 템플릿으로 일관된 PPT 생성 |
| **기존 PPT 수정** | 텍스트 교체, 슬라이드 재배열 |
| **PPT 분석** | 텍스트 추출, 구조 파악 |
| **템플릿 등록** | PPTX → YAML 템플릿 변환 |
| **디자인 검색** | 웹에서 PPT 디자인 레퍼런스 검색 |

### 지원 형식

- 입력: Markdown, JSON, 텍스트, 기존 PPTX
- 출력: PPTX (PowerPoint 2016+)

---

## PPT 생성 파이프라인 (5단계)

PPT 생성은 다음 5단계 파이프라인을 통해 진행됩니다. 각 단계는 별도 JSON 파일로 저장되어 디버깅과 세션 재개가 가능합니다.

```
┌─────────────────────────────────────────────────────────────────────────┐
│ 1단계: 설정 선택 (Setup)                                                 │
│ • 발표 주제/청중/목적 설정                                               │
│ • 테마 선택 (deepgreen, brandnew, default, custom)                      │
│ • 문서 종류 결정 (제안서, 보고서, 사업계획서 등)                          │
│ 📄 저장: stage-1-setup.json                                             │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 2단계: 발표내용 생성 (Outline)                                           │
│ • 슬라이드 목록 및 제목 생성                                             │
│ • 각 슬라이드별 핵심 포인트 정리                                         │
│ 📄 저장: stage-2-outline.json                                           │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 3단계: 콘텐츠 종류 선정 (Template Matching)                               │
│ • registry.yaml에서 최적 템플릿 매칭                                     │
│ • 슬라이드별 레이아웃 타입 결정                                          │
│ 📄 저장: stage-3-matching.json                                          │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 4단계: 콘텐츠 생성 (Content Generation)                                   │
│ • 템플릿 + 콘텐츠 → HTML 슬라이드 생성                                   │
│ • 디자인 토큰 → 테마 색상 치환                                           │
│ 📁 출력: slides/slide-001.html, slide-002.html, ...                      │
│ 📄 저장: stage-4-content.json                                           │
└─────────────────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 5단계: PPT 생성 (PPTX Generation)                                        │
│ • HTML → PPTX 변환 (html2pptx.js)                                        │
│ • 썸네일 생성 (검증용)                                                   │
│ 📁 출력: output.pptx, thumbnails/grid.jpg                                │
│ 📄 저장: stage-5-generation.json                                        │
└─────────────────────────────────────────────────────────────────────────┘
```

### Output 폴더 구조

```
output/
    {session-id}/                    # 세션 폴더 (예: 2026-01-09_143025_project-plan)
        session.json                 # 세션 메타 (ID, 상태, 현재 단계)
        stage-1-setup.json           # 1단계: 설정 선택
        stage-2-outline.json         # 2단계: 발표내용 생성
        stage-3-matching.json        # 3단계: 템플릿 매칭
        stage-4-content.json         # 4단계: 콘텐츠 생성
        stage-5-generation.json      # 5단계: PPT 생성 결과
        slides/                      # HTML 슬라이드
            slide-001.html
            slide-002.html
        assets/                      # 에셋 파일
        output.pptx                  # 최종 PPTX
        thumbnails/                  # 검증용 썸네일
            grid.jpg
```

### 세션 관리

| 기능 | 설명 |
|------|------|
| **세션 재개** | 중단된 세션을 `session.json`의 `current_stage`부터 이어서 진행 |
| **단계별 디버깅** | 각 단계 JSON 파일로 중간 상태 확인 가능 |
| **피드백 루프** | 5단계 완료 후 수정 필요 시 해당 단계로 돌아가기 |

> 📄 상세 스키마: [PRD_PPT_Skills_Suite.md](PRD_PPT_Skills_Suite.md) 섹션 13 참조

---

## 빠른 시작

### 1. 새 PPT 만들기

```
사용자: AI 트렌드에 대한 PPT 5장 만들어줘

Claude: [콘텐츠 분석 → 디자인 선택 → HTML 생성 → PPTX 변환]
        → output.pptx 생성 완료
```

### 2. 템플릿으로 PPT 만들기

```
사용자: 동국제강 양식으로 분기 실적 보고서 만들어줘

Claude: [템플릿 로드 → 콘텐츠 매핑 → 텍스트 교체]
        → 동국제강_실적보고서.pptx 생성 완료
```

### 3. 기존 PPT 수정하기

```
사용자: 이 PPT의 2번째 슬라이드 제목을 "새로운 전략"으로 바꿔줘

Claude: [PPTX 언팩 → XML 수정 → 리팩]
        → modified.pptx 생성 완료
```

---

## 워크플로우

### 워크플로우 선택 가이드

| 사용자 요청 | 워크플로우 | 설명 |
|------------|-----------|------|
| "PPT 만들어줘" | `html2pptx` | 새 PPT 생성 (템플릿 없음) |
| "동국제강 양식으로" | `template` | 템플릿 기반 생성 |
| "이 PPT 수정해줘" | `ooxml` | 기존 PPT 편집 |
| "PPT 분석해줘" | `analysis` | 텍스트/구조 추출 |
| "콘텐츠 추출해줘" | `content-extract` | 슬라이드 레이아웃 추출 (v2.0 스키마) |
| "문서 양식 추출해줘" | `document-extract` | 전체 문서 템플릿 등록 |
| "이 이미지 스타일 추출해줘" | `style-extract` | LLM Vision으로 스타일 추출 → 자동 저장 |
| "PPT 디자인 찾아줘" | `design-search` | 웹 디자인 검색 |
| "템플릿 목록 보여줘" | `template-manage` | 템플릿 관리 |
| "아이콘/이미지 저장해줘" | `asset-manage` | 에셋 관리 |
| "썸네일 생성해줘" | `thumbnail` | 썸네일 그리드 생성 |

> 📂 상세 가이드: [workflows/](workflows/) 폴더에서 각 워크플로우별 문서 참조

---

## 사용 예시

### 예시 1: 사업계획서 PPT 생성

**사용자 입력:**
```
다음 내용으로 사업계획서 PPT를 만들어줘:

# 스마트팜 사업계획서

## 1. 사업 개요
- IoT 기반 스마트 농업 솔루션
- 타겟: 중소규모 농가
- 목표: 생산성 30% 향상

## 2. 시장 분석
- 국내 스마트팜 시장: 2조원 (2025)
- 연평균 성장률: 15%
- 경쟁사: A사, B사

## 3. 핵심 기술
- 센서 네트워크
- AI 작물 분석
- 자동화 시스템

## 4. 사업 전략
1. 파일럿 농가 확보 (Q1)
2. 솔루션 고도화 (Q2-Q3)
3. 본격 사업화 (Q4)

## 5. 재무 계획
- 초기 투자: 5억원
- BEP: 2년차
- 5년 매출 목표: 100억원
```

**Claude 응답:**
```
사업계획서 PPT를 생성하겠습니다.

디자인 접근:
- 색상: Forest Green (#4E9F3D) 기반 - 농업/친환경 테마
- 레이아웃: 2열 비대칭 (텍스트 40% + 비주얼 60%)
- 폰트: Arial Bold (제목) + Arial (본문)

[HTML 슬라이드 생성 중...]
[PPTX 변환 중...]
[썸네일 검증 중...]

완료! 파일: smartfarm_business_plan.pptx (5 슬라이드)

슬라이드 구성:
1. 표지 - 스마트팜 사업계획서
2. 사업 개요 - 3개 핵심 포인트 카드
3. 시장 분석 - 시장 규모 차트
4. 핵심 기술 & 전략 - 타임라인
5. 재무 계획 - 주요 지표 카드
```

---

### 예시 2: 템플릿 기반 보고서 생성

**사용자 입력:**
```
동국제강 양식으로 2024년 3분기 실적 보고서 만들어줘:

- 매출: 1조 2천억 (전년비 +5%)
- 영업이익: 800억 (전년비 +12%)
- 주요 성과: 친환경 철강 라인 가동
- 다음 분기 전망: 수출 확대
```

**Claude 응답:**
```
동국제강 템플릿을 사용하여 보고서를 생성하겠습니다.

템플릿 정보:
- 그룹: dongkuk
- 양식: 보고서1 (제안서1.yaml)
- 테마: 네이비(#002452) + 레드(#C51F2A)

[템플릿 로드...]
[콘텐츠 매핑...]
[텍스트 교체...]

완료! 파일: 동국제강_2024Q3_실적보고서.pptx

슬라이드 구성:
1. 표지 - 2024년 3분기 실적 보고서
2. 목차
3. 핵심 실적 - 매출/영업이익 카드
4. 주요 성과 - 친환경 철강 라인
5. 향후 전망 - 수출 확대 계획
```

---

### 예시 3: 기존 PPT 수정

**사용자 입력:**
```
첨부한 presentation.pptx 파일에서:
1. 3번째 슬라이드 제목을 "신규 전략"으로 변경
2. 5번째 슬라이드를 2번째로 이동
3. 모든 "2023년"을 "2024년"으로 변경
```

**Claude 응답:**
```
PPT 수정을 진행하겠습니다.

[1단계] PPTX 언팩...
[2단계] 텍스트 인벤토리 추출...

발견된 항목:
- 슬라이드 3 제목: "기존 전략" → "신규 전략"
- "2023년" 발견: 7개 위치
- 슬라이드 순서: 1,2,3,4,5 → 1,5,2,3,4

[3단계] XML 수정...
[4단계] 슬라이드 재배열...
[5단계] PPTX 리팩...

완료! 파일: presentation_modified.pptx

변경 사항:
✓ 슬라이드 3 제목 변경
✓ 슬라이드 5 → 2번째로 이동
✓ "2023년" → "2024년" (7개소)
```

---

### 예시 4: PPTX를 템플릿으로 등록

**사용자 입력:**
```
첨부한 company_template.pptx를 "acme" 그룹의 "제안서1" 템플릿으로 등록해줘
```

**Claude 응답:**
```
PPTX를 템플릿으로 분석/등록하겠습니다.

[1단계] PPTX 분석...
  - 테마: Office Theme
  - 색상: Primary(#1F4E79), Secondary(#2E75B6)
  - 폰트: 맑은 고딕 Bold / Regular
  - 슬라이드: 6개

[2단계] 레이아웃 분류...
  - [0] cover - 표지
  - [1] toc - 목차
  - [2] content_bullets - 본문(불릿)
  - [3] content_free - 자유 영역
  - [4] content_bullets - 본문(불릿)
  - [5] cover - 마무리

[3단계] 그룹 폴더 생성...
  - templates/documents/acme/

[4단계] 파일 생성...
  - config.yaml (테마 설정)
  - 제안서1.yaml (양식 정의)
  - registry.yaml (목록 업데이트)

완료! 템플릿 등록됨:
- 그룹: acme
- ID: 제안서1
- 경로: templates/documents/acme/제안서1.yaml
```

---

### 예시 5: 디자인 레퍼런스 검색

**사용자 입력:**
```
미니멀한 테크 스타트업 PPT 디자인 찾아줘
```

**Claude 응답:**
```
웹에서 디자인 레퍼런스를 검색합니다...

[검색 키워드]
- "minimal tech startup presentation design"
- "modern pitch deck template 2024"

[발견된 레퍼런스]
1. Dribbble - Minimal Tech Pitch Deck
   - 색상: 다크모드 (#1A1A2E) + 네온 액센트
   - 특징: 큰 타이포, 여백 활용

2. Behance - Startup Presentation
   - 색상: 화이트 + 블루 그라데이션
   - 특징: 아이콘 중심, 심플한 차트

3. Pinterest - SaaS Deck Collection
   - 색상: 퍼플 (#7C3AED) + 민트
   - 특징: 카드 레이아웃, 스크린샷 강조

[추천 스타일]
- 다크 배경 + 네온 액센트 (트렌디)
- 화이트 + 단일 포인트 컬러 (클래식)

이 스타일로 PPT를 만들어드릴까요?
```

---

## 템플릿 시스템

### 3타입 구조

```
templates/
├── documents/          # [타입 1] 문서 템플릿 (회사/브랜드별)
│   └── dongkuk/
│       ├── config.yaml      # 그룹 테마 (색상, 폰트)
│       ├── registry.yaml    # 양식 목록
│       ├── assets/          # 로고, 이미지
│       └── 제안서1.yaml     # 양식 정의
│
├── contents/           # [타입 2] 콘텐츠 템플릿 (슬라이드 패턴)
│   ├── registry.yaml
│   └── templates/
│       ├── cover1.yaml      # 표지
│       ├── toc1.yaml        # 목차
│       ├── timeline1.yaml   # 타임라인
│       └── comparison1.yaml # 비교
│
└── assets/             # [타입 3] 공용 에셋
    ├── registry.yaml
    ├── icons/
    └── images/
```

### 문서 템플릿 사용

```yaml
# templates/documents/dongkuk/제안서1.yaml
document:
  id: 제안서1
  name: 제안서 (기본)
  source: .claude/includes/PPT기본양식.pptx

slides:
  - category: cover
    slide_index: 0
  - category: toc
    slide_index: 1
  - category: body
    slide_index: 2
```

### 콘텐츠 템플릿 종류

| ID | 이름 | 용도 |
|----|------|------|
| cover1 | 표지 (기본) | 프레젠테이션 시작 |
| toc1 | 목차 (기본) | 아젠다, 순서 |
| comparison1 | 비교 (A vs B) | Before/After, 장단점 |
| timeline1 | 타임라인 | 로드맵, 일정 |
| process-flow1 | 프로세스 | 단계별 절차 |
| stat-cards1 | 통계 카드 | KPI, 핵심 지표 |
| feature-grid1 | 기능 그리드 | 기능 소개, 특징 |
| pros-cons1 | 장단점 | Pros/Cons 분석 |

---

## 스크립트 사용법

### html2pptx.js - HTML → PPTX 변환

```bash
# 기본 사용
node scripts/html2pptx.js slides/ output.pptx

# 옵션
node scripts/html2pptx.js slides/ output.pptx --layout 16x9
```

### template-analyzer.py - PPTX → YAML 분석

```bash
# 새 그룹에 템플릿 등록
python scripts/template-analyzer.py input.pptx 제안서1 --group mycompany

# 옵션
python scripts/template-analyzer.py input.pptx 보고서1 \
  --group dongkuk \
  --name "보고서 (기본)" \
  --type report \
  --description "표지 + 데이터 중심 본문"
```

### inventory.py - 텍스트 추출

```bash
# PPTX에서 텍스트 인벤토리 추출
python scripts/inventory.py input.pptx > inventory.json
```

### replace.py - 텍스트 교체

```bash
# JSON 매핑으로 텍스트 교체
python scripts/replace.py input.pptx replacements.json output.pptx
```

### rearrange.py - 슬라이드 재배열

```bash
# 슬라이드 순서 변경 (1,3,2,4 순서로)
python scripts/rearrange.py input.pptx "1,3,2,4" output.pptx
```

### thumbnail.py - 썸네일 생성

```bash
# 그리드 썸네일 생성 (검증용)
python scripts/thumbnail.py input.pptx output_dir/ --cols 4

# 단일 슬라이드 썸네일 (1980x1080 PNG)
python scripts/thumbnail.py input.pptx output/ --slides 5 --single

# 여러 슬라이드 개별 추출
python scripts/thumbnail.py input.pptx output/ --slides 1,3,5
```

### asset-manager.py - 에셋 관리

PPT 생성에 사용할 아이콘, 이미지 등의 에셋을 관리합니다.

```bash
# 아이콘 추가 (로컬 파일)
python scripts/asset-manager.py add icon.svg --id chart-line --tags "chart,analytics"

# URL에서 이미지 추가
python scripts/asset-manager.py add "https://example.com/bg.png" --id hero-bg --tags "background"

# 검색
python scripts/asset-manager.py search chart
python scripts/asset-manager.py search --tags background

# 목록 조회
python scripts/asset-manager.py list
python scripts/asset-manager.py list --type icons --format table
python scripts/asset-manager.py list --format json

# 상세 정보
python scripts/asset-manager.py info chart-line

# 삭제
python scripts/asset-manager.py delete chart-line
python scripts/asset-manager.py delete chart-line -f  # 확인 없이
```

### template-manager.py - 템플릿 관리

문서 템플릿과 콘텐츠 템플릿을 조회/삭제/아카이브합니다.

```bash
# 전체 목록
python scripts/template-manager.py list

# 타입별 목록
python scripts/template-manager.py list --type documents
python scripts/template-manager.py list --type contents

# 아카이브 포함 조회
python scripts/template-manager.py list --archived

# 상세 정보
python scripts/template-manager.py info 제안서1
python scripts/template-manager.py info 제안서1 --preview  # 내용 미리보기

# 아카이브 (숨김)
python scripts/template-manager.py archive 제안서1

# 복원
python scripts/template-manager.py restore 제안서1

# 삭제
python scripts/template-manager.py delete 제안서1
python scripts/template-manager.py delete 제안서1 -f  # 확인 없이
```

### style-extractor.py - 이미지 스타일 추출 (선택적 CLI)

> **권장:** 자연어로 요청하면 Claude가 LLM Vision으로 직접 분석 후 자동 저장합니다.
>
> ```
> [이미지 첨부] "이 이미지 스타일 추출해서 저장해줘"
> → Claude가 색상 분석 → 무드 분류 → 3타입 구조에 자동 저장
> ```

이 스크립트는 **대량 배치 처리**나 **자동화 파이프라인**용입니다.

```bash
# YAML 스타일 가이드 생성
python scripts/style-extractor.py design.png --output style.yaml

# 색상만 추출 (6개)
python scripts/style-extractor.py design.png --colors-only --count 6

# CSS 변수로 출력
python scripts/style-extractor.py design.png --format css

# JSON 출력
python scripts/style-extractor.py design.png --format json
```

**출력 예시 (YAML):**
```yaml
colors:
  palette: [4E9F3D, 1E5128, D8E9A8, 7BC74D, FFFFFF]
  roles:
    primary: 4E9F3D
    secondary: 1E5128
    accent: D8E9A8
    background: FFFFFF
    text: 1E5128
```

**의존성:** `pip install Pillow` (선택: `colorthief`)

### slide-crawler.py - 온라인 슬라이드 크롤링

SlideShare, Speaker Deck 등에서 슬라이드를 크롤링하여 콘텐츠 템플릿으로 변환합니다.

```bash
# SlideShare에서 크롤링
python scripts/slide-crawler.py "https://www.slideshare.net/user/deck" --output my-template

# 카테고리 지정
python scripts/slide-crawler.py "https://speakerdeck.com/user/deck" --output timeline2 --category timeline

# 분석만 (저장 안함)
python scripts/slide-crawler.py "https://slideshare.net/..." --analyze-only
```

**지원 사이트:**
- SlideShare (slideshare.net)
- Speaker Deck (speakerdeck.com)
- 기타 웹페이지 (이미지 기반 추출)

**의존성:** `pip install requests beautifulsoup4`

---

## 폴더 구조

```
.claude/skills/ppt-gen/
├── README.md              # 이 문서
├── SKILL.md               # 스킬 정의 (엔트리포인트, ~80줄)
├── GUIDE.md               # 학습 가이드
├── html2pptx.md           # HTML 생성 상세 가이드
├── ooxml.md               # OOXML 편집 상세 가이드
│
├── workflows/             # 워크플로우별 가이드 (NEW)
│   ├── analysis.md        # PPT 분석/읽기
│   ├── html2pptx.md       # 새 PPT 생성
│   ├── ooxml.md           # 기존 PPT 편집
│   ├── template.md        # 템플릿 기반 생성
│   ├── content-extract.md # 콘텐츠 추출 (v2.0)
│   ├── document-extract.md # 문서 양식 추출
│   ├── style-extract.md   # 이미지 스타일 추출
│   ├── design-search.md   # 디자인 검색
│   ├── template-manage.md # 템플릿 관리
│   ├── asset-manage.md    # 에셋 저장/검색
│   └── thumbnail.md       # 썸네일 생성
│
├── scripts/
│   ├── html2pptx.js       # HTML → PPTX 변환
│   ├── template-analyzer.py # PPTX → YAML 분석
│   ├── inventory.py       # 텍스트 추출
│   ├── replace.py         # 텍스트 교체
│   ├── rearrange.py       # 슬라이드 재배열
│   ├── thumbnail.py       # 썸네일 생성
│   ├── asset-manager.py   # 에셋 관리 (추가/검색/삭제)
│   ├── template-manager.py # 템플릿 관리 (목록/아카이브)
│   ├── style-extractor.py # 이미지 스타일 추출
│   └── slide-crawler.py   # 온라인 슬라이드 크롤링
│
├── templates/
│   ├── documents/         # 문서 템플릿
│   ├── contents/          # 콘텐츠 템플릿
│   └── assets/            # 공용 에셋
│
├── references/
│   ├── custom-elements.md # HTML 요소 스키마
│   ├── design-system.md   # 디자인 규칙
│   ├── color-palettes.md  # 컬러 팔레트
│   └── content-schema.md  # 콘텐츠 템플릿 v2.0 스키마
│
└── ooxml/
    └── scripts/           # OOXML 편집 스크립트
```

---

## 레퍼런스 문서

### custom-elements.md

HTML → PPTX 변환 시 지원되는 요소:

- **HTML 태그**: p, h1-h6, ul, ol, li, div, img, span, b, i, u
- **CSS 스타일**: fontSize, color, backgroundColor, border, boxShadow
- **Placeholder**: 차트/표 위치 예약

### design-system.md

PPT 디자인 규칙:

- **슬라이드 크기**: 720×405px (16:9)
- **타이포그래피**: 웹 안전 폰트, 크기 계층
- **레이아웃**: 2열 비대칭 권장, 30px 여백
- **불릿**: `<ul>/<ol>` 사용, 최대 4개

### color-palettes.md

사용 가능한 컬러 팔레트:

- **브랜드**: 동국그룹 (네이비 + 레드)
- **범용**: 18개 팔레트 (Classic Blue, Teal & Coral, Bold Red 등)
- **선택 가이드**: 산업별, 무드별 권장 팔레트

### content-schema.md (v2.0)

콘텐츠 템플릿 YAML 스키마:

- **도형 정보**: type, geometry (x, y, cx, cy %), style, text
- **시맨틱 색상**: primary, secondary, accent, background
- **디자인 메타**: quality_score, design_intent (40개 카테고리)
- **공간 관계**: gaps, spatial_relationships, groups
- **필수**: thumbnail 경로

---

## 트러블슈팅

### 일반 문제

**Q: PPT 파일이 열리지 않아요**
```
A: 썸네일로 시각적 검증 후 생성하세요:
   python scripts/thumbnail.py output.pptx thumbnails/

   자주 발생하는 원인:
   - HEX 색상에 # 포함 (제거 필요)
   - body 크기와 레이아웃 불일치
```

**Q: 텍스트가 잘려요**
```
A: 폰트 크기를 줄이거나 여백을 늘리세요.
   - 본문: 14-18pt 권장
   - 제목: 36-48pt 권장
   - 하단 여백: 최소 30px
```

**Q: 이미지가 안 나와요**
```
A: 이미지 경로를 절대 경로로 지정하세요.
   - 상대 경로: X
   - 절대 경로: O (file:///C:/path/to/image.png)
```

### 템플릿 문제

**Q: 템플릿이 인식되지 않아요**
```
A: registry.yaml에 등록되어 있는지 확인하세요:
   templates/documents/{그룹}/registry.yaml
```

**Q: 색상이 이상하게 나와요**
```
A: HEX 색상에서 # 제외:
   - 잘못: "#FF0000"
   - 올바름: "FF0000"
```

### 스크립트 문제

**Q: html2pptx.js 실행 오류**
```
A: Node.js 의존성 설치:
   npm install pptxgenjs playwright sharp
```

**Q: Python 스크립트 오류**
```
A: Python 의존성 설치:
   pip install python-pptx pyyaml
```

---

## 의존성

### Node.js
- pptxgenjs: PPT 생성
- playwright: HTML 렌더링
- sharp: 이미지 처리

### Python (필수)
- python-pptx: PPT 편집
- pyyaml: YAML 파싱
- markitdown: 문서 변환

### Python (유틸리티별)
- Pillow: 이미지 처리 (style-extractor)
- colorthief: 색상 추출 (style-extractor, 선택)
- requests: HTTP 요청 (asset-manager, slide-crawler)
- beautifulsoup4: HTML 파싱 (slide-crawler)

```bash
# 전체 설치
pip install python-pptx pyyaml Pillow requests beautifulsoup4

# 선택적 설치 (색상 추출 향상)
pip install colorthief
```

---

## 라이선스

Proprietary. LICENSE.txt 참조.
